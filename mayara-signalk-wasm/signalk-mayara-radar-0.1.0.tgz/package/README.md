# Mayara SignalK WASM Plugin

Marine radar plugin for SignalK Server that detects and streams data from marine radars.

## Supported Radars

- **Furuno** - DRS4D-NXT and similar (primary target)
- **Navico** - BR24, 3G, 4G, HALO (planned)
- **Raymarine** - Quantum, RD series (planned)
- **Garmin** - xHD/HD (planned)

## Requirements

- SignalK Server 3.0+ with WASM plugin support
- `rawSockets` capability enabled
- Rust toolchain with `wasm32-wasip1` target (for building from source)

## Network Setup

### Furuno Radars

Furuno radars require a dedicated network interface with specific IP configuration:

- **IP Address**: `172.31.3.x` (e.g., `172.31.3.1`)
- **Subnet Mask**: `255.255.0.0`
- **Broadcast Address**: `172.31.255.255`

The radar uses port `10010` for beacon discovery. Ensure your firewall allows UDP traffic on this port.

Example Linux network configuration:
```bash
# Add secondary IP to eth1 for radar network
sudo ip addr add 172.31.3.1/16 dev eth1
```

Or permanently in `/etc/network/interfaces`:
```
auto eth1
iface eth1 inet static
    address 172.31.3.1
    netmask 255.255.0.0
```

## Building

### Install WASM Target

```bash
rustup target add wasm32-wasip1
```

### Build Release Binary

```bash
cd mayara-signalk-wasm
cargo build --target wasm32-wasip1 --release
```

The WASM binary will be at `target/wasm32-wasip1/release/mayara_signalk_wasm.wasm`.

### Rename for SignalK

```bash
cp target/wasm32-wasip1/release/mayara_signalk_wasm.wasm plugin.wasm
```

## Installation

### Method 1: Manual Install

```bash
# Create plugin directory
mkdir -p ~/.signalk/node_modules/@signalk/mayara-radar

# Copy files
cp plugin.wasm package.json ~/.signalk/node_modules/@signalk/mayara-radar/
```

### Method 2: Development Link

```bash
cd ~/.signalk/node_modules
mkdir -p @signalk
ln -s /path/to/mayara/mayara-signalk-wasm @signalk/mayara-radar
```

## Configuration

In SignalK admin UI, navigate to **Server > Plugin Config > Mayara Marine Radar**.

Options:
- **Enable Radar Detection** - Turn on/off radar scanning
- **Radar Brand** - Select your radar brand (furuno, navico, raymarine, garmin)
- **Network Interface** - Optionally limit to specific interface

## SignalK Data Paths

The plugin emits radar data to these SignalK paths:

| Path | Description |
|------|-------------|
| `sensors.radar.<id>.brand` | Radar manufacturer |
| `sensors.radar.<id>.model` | Radar model |
| `sensors.radar.<id>.address` | Radar IP address |
| `sensors.radar.<id>.status` | Status (scanning, found, connected, error) |

## Architecture

This WASM plugin uses SignalK's `rawSockets` capability to access UDP sockets for radar discovery:

1. **Discovery**: Sends broadcast beacon to find radars on the network
2. **Detection**: Parses radar announcement packets
3. **Delta Emission**: Emits radar metadata to SignalK data model

## Differences from Native Mayara

This WASM plugin is a simplified version focused on radar discovery and status reporting. For full radar data streaming (spoke data, controls), use the native `mayara-server`.

| Feature | Native | WASM |
|---------|--------|------|
| Radar Discovery | Yes | Yes |
| Radar Controls | Yes | No |
| Spoke Data Streaming | Yes | No (planned) |
| WebSocket Server | Yes | No (uses SignalK) |
| Multiple Brands | Yes | Furuno only (others planned) |

## Development

### Debug Build

```bash
cargo build --target wasm32-wasip1
```

### Check Syntax

```bash
cargo check --target wasm32-wasip1
```

### View Debug Logs

Set debug logging in SignalK:

```bash
DEBUG=signalk:wasm:* signalk-server
```

## License

Apache License 2.0
